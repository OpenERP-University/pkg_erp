# com_hrm
- quản lý nhân sự - HRM
- component được sử dụng cùng component Financial management com_fm
- download com_fm tại địa chỉ : https://github.com/OpenERP-University/com_fm


#Tính năng nổi bật
- quản lý thông tin lý lịch cán bộ
- quản lý thông tin sửa đổi bằng version
- quản lý thông tin quá trình lương của cán bộ
- cho phép cấu hình email tự động khi thay đổi
- cho phép bật tắt chế độ version
- cho phép chọn chế độ nâng bậc tự khi đến hạn định - gửi mail cho nhóm người dùng nhận mail thông báo danh sách cán bộ nâng bậc và các bộ sắp được nâng bậc

#Link hướng dẫn sử dụng 

https://www.youtube.com/watch?v=NSIYjhTmi4g&list=PL25QCJwTN8x5Cy7cTETifUwAKl7mI8GxH
