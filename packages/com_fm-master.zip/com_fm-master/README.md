# com_fm
component joomla Financial management - Quản lý tài chính 
sử dụng thư viện PHPexcel để xây dựng các bảng ecxel 

download thư viện PHPexcel cho joomla tại :
https://github.com/vdespa/PHPExcel-Joomla-Library

Cài đặt component quản lý cán bộ tại
https://github.com/OpenERP-University/com_hrm

thông tin cán bộ sẽ được thêm vào dữ liệu quán lý tài chính khi cán bộ được tạo mới

#Quản lý tài chính
- quản lý thông tin lương của cán bộ
- quản lý lịch sử lương của các cạn bộ theo tháng - năm
- lịch sử lương cán bộ được lưu trong csdl có thể lấy ra bất kỳ lúc nào
- tự động tính lương vào ngày cố định trong tháng (không thể xem lương tháng này khi chưa đến ngày tính lương) 
- hệ thống in bảng lương theo tháng - năm 
- hệ thống in bảng lương theo cán bộ (nhóm cán bộ) (đang xây dựng)
